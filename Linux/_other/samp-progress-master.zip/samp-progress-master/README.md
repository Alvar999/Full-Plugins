[NEW VERSION NOW AVAILABLE](https://github.com/Southclaw/progress2)
